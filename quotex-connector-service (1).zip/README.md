# Auto-generated connector service

Everything here was generated from the uploaded ZIP. Nothing needs editing.

1. Create a new **Docker** web service on Render / Railway / Fly using this folder.
2. Set one environment variable if the host does not provide it automatically:
   - `PAIR_CODE` = qx-s7f6gluyceo4
3. Deploy. On boot the service reports its own public address back to the site,
   and the setup screen continues on its own.

Credentials are posted straight to this service over HTTPS and kept in process
memory only. They are never written to disk, a database, or the browser.
